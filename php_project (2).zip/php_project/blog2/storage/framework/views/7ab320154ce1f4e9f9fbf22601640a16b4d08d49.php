<form action="insert">
    <h1>Insert:</h1><input type="submit" value="Insert">

</form>

<!DOCTYEPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<h2>Names and age :</h2>


<table border="1">
    <tr>
        <td>
            ID
        </td>
        <td>
            Name
        </td>
        <td>
            Age
        </td>
        <td>
            Show
        </td>
        <td>
            Delete
        </td>
        <td>
            Edit
        </td>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($daata['id']); ?>

            </td>
            <td>
                <?php echo e($daata['name']); ?>

            </td>
            <td>
                <?php echo e($daata['age']); ?>

            </td>
            <td>
                

                <form action=<?php echo e($daata->id); ?>>

                    <input type="submit" value="Show">

                </form>
            </td>
            <td>

            <a href="delete/<?php echo e($daata->id); ?>" class="btn btn-danger ">Delete</a>

            </td>
            <td>

                <a href="edit/<?php echo e($daata->id); ?>" class="btn btn-danger ">Edit</a>

            </td>

        </tr>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</table>













</body>
</html>
