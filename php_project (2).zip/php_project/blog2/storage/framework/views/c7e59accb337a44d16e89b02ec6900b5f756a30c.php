
<form action="home" method="POST">
    <?php echo csrf_field(); ?>
    <h2>Name.</h2>
    <input type="text" id="name" name="name" required><br>
    <h3>Age.</h3>
    <input type="number" id="age" name="age"  required><br><br>
    <input type="submit" value="submit">
</form>
