<form action="insert">
    <h1>Insert:</h1><input type="submit" value="Insert">

</form>

<!DOCTYEPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<h2>Names and age :</h2>


<table border="1">
    <tr>
        <td>
            ID
        </td>
        <td>
            Name
        </td>
        <td>
            Age
        </td>
        <td>
            Show
        </td>
        <td>
            Delete
        </td>
        <td>
            Edit
        </td>
    </tr>
    @foreach($data as $daata)
        <tr>
            <td>
                {{$daata['id']}}
            </td>
            <td>
                {{$daata['name']}}
            </td>
            <td>
                {{$daata['age']}}
            </td>
            <td>
                {{--                <form action={{  }}>--}}

                <form action={{$daata->id}}>

                    <input type="submit" value="Show">

                </form>
            </td>
            <td>

            <a href="delete/{{$daata->id}}" class="btn btn-danger ">Delete</a>

            </td>
            <td>

                <a href="edit/{{$daata->id}}" class="btn btn-danger ">Edit</a>

            </td>

        </tr>



    @endforeach




</table>













</body>
</html>
