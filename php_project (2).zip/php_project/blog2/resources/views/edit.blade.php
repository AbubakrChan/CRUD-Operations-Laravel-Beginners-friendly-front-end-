
<form action="/edit" method="post">
    @csrf
    <input type="hidden" id="id" name="id" value="{{$data['id']}}" ><br>
    <h2>Name.</h2>
    <input type="text" id="name" name="name" value="{{$data['name']}}" required><br>
    <h3>Age.</h3>
    <input type="number" id="age" name="age"  value="{{$data['age']}}" required><br><br>
    <input type="submit" value="Update">
</form>
