<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mymodel extends Model
{
    //
    //protected   $fillable = ['name', 'age'];
    protected $table  = 'user';
   public $timestamps = false;
}
