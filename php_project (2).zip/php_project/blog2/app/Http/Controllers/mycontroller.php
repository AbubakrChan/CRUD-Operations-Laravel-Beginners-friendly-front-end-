<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\mymodel;

class mycontroller extends Controller
{
    ////////////////////////////////////////
    function home(){
        $data = mymodel::all();
        return view('myhome')->with('data',$data);
    }
    ///////////////////////////////////////////
    function submit(Request $req){
        $user  = new mymodel();
        $user->name =$req->name;
        $user->age =$req->age;
        $user->save();
        $data = mymodel::all();
        return view('myhome')->with('data',$data);
    }
    ////////////////////////////////////////

    function read(){
        $data = mymodel::all();
        foreach ($data as $daata){


            if($daata['id']  == request('id')){
                echo "Name:    " , $daata['name'] ,"<br>" ,  "Age:    " ,$daata['age'];

            }
        }

    }
    /////////////////////////////////////
   function delete($id){
        $delete = mymodel::find($id);
        $delete->delete();
        return redirect('home');
    }
    ////////////////////////////
    ///
    ///
    function edit($id){
        $mydata = mymodel::find($id);
        return view('edit',['data'=>$mydata]);
    }
    function update(Request $req){
       $dataa = mymodel::find($req->id);
       //echo "1";
        //echo $dataa;
        $dataa->name = $req->name;
        $dataa->age = $req->age;
        $dataa->save();


        return redirect('home');
    }
}
